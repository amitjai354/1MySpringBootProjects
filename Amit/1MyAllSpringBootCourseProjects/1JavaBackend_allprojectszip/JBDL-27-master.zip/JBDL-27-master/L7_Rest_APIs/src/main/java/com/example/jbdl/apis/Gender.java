package com.example.jbdl.apis;

public enum Gender {

    MALE,
    FEMALE
}
