public class Main {

    public static void main(String[] args) {
        // Q1. find the product of 3 and 10 but using maven test project

        System.out.println(Calculator.multiply(3, 10));
        System.out.println(Calculator.divide(34, 3));
        System.out.println(Calculator.power(2, 3));
    }
}
