package com.example.jbdl.demodb.repositories;

import com.example.jbdl.demodb.models.Book;
import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

    // This is the place where we wil write sql queries and code related to db integration

    public void insert(Book book){
        // TODO: Add sql queries here
    }
}
