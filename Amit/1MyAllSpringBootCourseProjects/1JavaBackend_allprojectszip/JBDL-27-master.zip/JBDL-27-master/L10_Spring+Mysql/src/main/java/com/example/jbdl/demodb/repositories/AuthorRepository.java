package com.example.jbdl.demodb.repositories;

public class AuthorRepository {
}
