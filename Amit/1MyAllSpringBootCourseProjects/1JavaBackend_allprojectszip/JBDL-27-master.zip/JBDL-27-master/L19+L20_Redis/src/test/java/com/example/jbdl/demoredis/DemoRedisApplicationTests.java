package com.example.jbdl.demoredis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
