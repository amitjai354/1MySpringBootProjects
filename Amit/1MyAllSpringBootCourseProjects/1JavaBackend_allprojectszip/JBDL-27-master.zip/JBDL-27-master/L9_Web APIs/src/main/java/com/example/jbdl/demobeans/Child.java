package com.example.jbdl.demobeans;

public class Child extends Parent{

    @Override
    public void test(){}
}
