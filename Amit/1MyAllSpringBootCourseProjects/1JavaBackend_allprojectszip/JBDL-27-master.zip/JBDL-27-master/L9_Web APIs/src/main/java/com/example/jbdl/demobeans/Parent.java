package com.example.jbdl.demobeans;

public class Parent {

    public void test(){}
}
