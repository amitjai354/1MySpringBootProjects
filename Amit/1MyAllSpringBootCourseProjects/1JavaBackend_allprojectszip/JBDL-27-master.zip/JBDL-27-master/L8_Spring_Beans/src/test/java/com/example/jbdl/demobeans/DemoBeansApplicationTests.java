package com.example.jbdl.demobeans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBeansApplicationTests {

	@Test
	void contextLoads() {
	}

}
