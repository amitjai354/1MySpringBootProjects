package com.example;

import java.util.ArrayList;
import java.util.HashMap;

public class Main extends PersonAbstractClass{

    // JAR - Java Archive

    public static void main(String[] args) {
        System.out.println("Hello world!!");

        ArrayList<Integer> al = new ArrayList<>();

//        Person person = new Person();
//        person.country = "India";
    }

    @Override
    public void testSomething() {

    }

    // .java files --> .class files
    // running .class file in the JVM
}
