package com.example.jbdl.ewallet;

public enum TransactionStatus {

    PENDING,
    SUCCESSFUL,
    FAILED
}
