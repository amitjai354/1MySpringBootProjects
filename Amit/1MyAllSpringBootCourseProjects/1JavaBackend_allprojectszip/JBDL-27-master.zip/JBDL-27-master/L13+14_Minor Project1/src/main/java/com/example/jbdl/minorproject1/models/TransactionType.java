package com.example.jbdl.minorproject1.models;

public enum TransactionType {

    ISSUE,
    RETURN
}
