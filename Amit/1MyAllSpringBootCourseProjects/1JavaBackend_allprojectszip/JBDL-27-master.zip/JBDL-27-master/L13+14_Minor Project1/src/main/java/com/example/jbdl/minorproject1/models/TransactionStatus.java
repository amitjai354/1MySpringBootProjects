package com.example.jbdl.minorproject1.models;

public enum TransactionStatus {

    PENDING,
    SUCCESS,
    FAILED
}
