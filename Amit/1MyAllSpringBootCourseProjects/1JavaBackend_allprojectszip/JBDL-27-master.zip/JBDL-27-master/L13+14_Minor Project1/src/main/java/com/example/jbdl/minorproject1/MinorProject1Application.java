package com.example.jbdl.minorproject1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinorProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(MinorProject1Application.class, args);
	}

}
