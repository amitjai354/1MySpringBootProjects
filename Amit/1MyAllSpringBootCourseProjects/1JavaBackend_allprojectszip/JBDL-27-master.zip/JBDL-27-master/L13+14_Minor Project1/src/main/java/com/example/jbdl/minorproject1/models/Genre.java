package com.example.jbdl.minorproject1.models;

public enum Genre {

                // STRING, ORDINAL
    FICTIONAL, // fictional 0
    NON_FICTIONAL,
    HOME_SCIENCE,
    BIOLOGY,
    CHEMISTRY,
    PHYSICS,
    MATHEMATICS,
    BUSINESS,
    ACCOUNTS,
    HISTORY
}
