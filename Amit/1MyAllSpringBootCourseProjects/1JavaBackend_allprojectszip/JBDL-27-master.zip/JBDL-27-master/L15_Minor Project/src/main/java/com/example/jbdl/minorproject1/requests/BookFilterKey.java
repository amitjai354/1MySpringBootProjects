package com.example.jbdl.minorproject1.requests;

public enum BookFilterKey {

    AUTHOR_NAME,
    BOOK_NAME,
    GENRE,
    BOOK_ID
}
