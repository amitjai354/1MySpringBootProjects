package com.example.jbdl.demosecuritydb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecurityDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
